import React, {useState} from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity } from 'react-native';

export default function App() {
    // Input Data:
    const [sideA, setSideA] = useState('');
    const [sideB, setSideB] = useState('');

    //Middle Data:
    const [a, setA] = useState(0);
    const [b, setB] = useState(0);

    //Results:
    const [error, setError] = useState('');
    const [length, setLength] = useState(null);
    const [area, setArea] = useState(null);

    //convert():
    function convert() {
        setA(parseFloat(sideA));
        setB(parseFloat(sideB));
    }

    //validate():
    function validate(){
        if(isNaN(a) || isNaN(b)){
            setError('Wrong input data')
            return false;
        }
        //2
        if (a <= 0 || b <= 0){
            setError('Довжини сторін повинні бути додатні');
            return false;
        }
        return true;  
    }

    // calc():
    function calc(){
        setError('');
        convert();
        if (validate()) {
            setLength((a+b) * 2);
            setArea((a*b).toFixed(2));
        }
    }

    //reset():
    function reset(){
        setSideA('');
        setSideB('');
        
    }

    //GUI
  return (
    <View style={styles.container}>
        {/** Заголовки */}
        <View style={{ alignItems: 'center', marginBottom: 15 }}>
            <Text style={{ fontSize: 24, fontWeight: 'semibold', color: 'purple' }}>
                Rectangle calculate without commertial and SMS
            </Text>
            <Text style={{ fontSize: 16, fontWeight: 'semibold', color: 'teal;', fontStyle: 'italic' }}>
                calculate Площі та переметру
            </Text>
        </View>
        {/** Форма введення даних */}
        <View style={{}}>
            <Text style={{ fontSize: 16, fontWeight: 'semibold', color: 'navy'}}>
                Довжина 1 сторони:
            </Text>
            <TextInput
                placeholder='input First size'
                style={{ marginTop: 5, borderWitdth: 1, height: 32,
                borderRadius:10, paddingHorizontal: 10,  
            }}
            value={sideA}
            onChangeText={setSideA}
            />
        </View>
            {/**-> */}
        <View style={{}}>
            <Text style={{ fontSize: 16, fontWeight: 'semibold', color: 'navy',
                marginTop: 10
            }}>
                Довжина 2 сторони:
            </Text>
            <TextInput
                placeholder='input Second size'
                style={{ marginTop: 5, borderWitdth: 1, height: 32,
                borderRadius:10, paddingHorizontal: 10,  
            }}
            value={sideB}
            onChangeText={setSideB}
            />
            {/**-> */}
            <TouchableOpacity 
                style={{
                    backgroundColor: 'lightgreen', borderRadius: 10,
                    flex: 1, alignItems: 'center', borderWidth: 2,
                    paddingVertical: 14, marginTop: 15, marginHorizontal: 20
                }}>
                onPress=(calc)

                <Text>Обчислити</Text>
            </TouchableOpacity>
        </View>
                    
        {/** Панель відображення результатів */}
        {area !== null &&(
            <View>
                <Text>
                    Результати обчислень:
                </Text>
                <Text>
                    Периметр: P = {length} од.
                </Text>
                <Text>
                    Площа: S = {area} кв.од.
                </Text>
            </View>
        )}
        <View>
            
        </View>

        {/** Панель відображення помилок */}
        <View>
            
        </View>        
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingTop: 15
  },
});
