using ImagesApp_WinF_.Repos;
using ImagesApp.Models;

namespace ImagesApp_WinF_
{
    public partial class Form1 : Form
    {
        private FilesRepo _repo;

        public Form1()
        {
            InitializeComponent();
            _repo = new FilesRepo();
        }

        private void OpenBTN_Click(object sender, EventArgs e)
        {
            var dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string folderPath = dialog.SelectedPath;
                string[] filePathes = Directory.GetFiles(folderPath);

                FilesList.DataSource = null;
                _repo.FillList(filePathes);

                FilesList.DataSource = _repo.FilesData;
                FilesList.DisplayMember = "FileName";
            }
            ;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BackBTN_Click(object sender, EventArgs e)
        {

        }

        private void NextBTN_Click(object sender, EventArgs e)
        {

        }

        private void FilesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            int k = FilesList.SelectedIndex;
            if (k > -0)
            {
                var item = FilesList.SelectedItem as ImageFile;
                ViewPanel.Image = Image.FromFile(item!.FilePath);
            }
        }
    }
}
