﻿using ImagesApp.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ImagesApp_WinF_.Repos
{
    public class FilesRepo
    {
        public List<ImageFile> FilesData { get; set; } = [];
        public void FillList(string[] pathes)
        {
            foreach (string path in pathes)
            {
                var imageFile = new ImageFile()
                {
                    FilePath = path,
                    FileName = Path.GetFileName(path),
                    FileExt = Path.GetExtension(path)
                };
                FilesData.Add(imageFile);
            }
        }
    }
}
